import React, { useState, useEffect } from "react";
import {
  Play,
  Pause,
  X,
  Check,
  Thermometer,
  Activity,
  Anchor,
  Zap,
  Minus,
  Save,
} from "lucide-react";
import BodyMap from "./BodyMap";
import { BodyData, BodyPartId, SensationType, BodyLog } from "../types";
import {
  playScanIntro,
  pauseScanIntro,
  stopScanIntro,
} from "../services/bodyScanService";
import { useFocusTrap } from "@/hooks/useFocusTrap";

interface ScannerProps {
  onComplete: (data: BodyData) => void;
}

const bodyPartTranslations: Record<string, string> = {
  head: "Cabeça",
  neck: "Pescoço",
  chest: "Peito",
  stomach: "Abdômen",
  leftArm: "Braço Esquerdo",
  rightArm: "Braço Direito",
  leftLeg: "Perna Esquerda",
  rightLeg: "Perna Direita",
  feet: "Pés",
};

const sensationConfig: Record<
  SensationType,
  {
    icon: any;
    label: string;
    textColor: string;
    borderColor: string;
    gradient: string;
    activeBorder: string;
  }
> = {
  tension: {
    icon: Activity,
    label: "Tensão",
    textColor: "text-clay",
    borderColor: "border-nevoa group-hover:border-clay/40",
    activeBorder: "border-clay bg-clay/5 ring-2 ring-clay/20",
    gradient: "from-clay/10 to-transparent",
  },
  heat: {
    icon: Thermometer,
    label: "Calor",
    textColor: "text-ochre",
    borderColor: "border-nevoa group-hover:border-ochre/40",
    activeBorder: "border-ochre bg-ochre/5 ring-2 ring-ochre/20",
    gradient: "from-ochre/10 to-transparent",
  },
  weight: {
    icon: Anchor,
    label: "Peso",
    textColor: "text-ocean",
    borderColor: "border-nevoa group-hover:border-ocean/40",
    activeBorder: "border-ocean bg-ocean/5 ring-2 ring-ocean/20",
    gradient: "from-ocean/10 to-transparent",
  },
  tingling: {
    icon: Zap,
    label: "Formigar",
    textColor: "text-amber-500",
    borderColor: "border-nevoa group-hover:border-amber-500/40",
    activeBorder: "border-amber-500 bg-amber-500/5 ring-2 ring-amber-500/20",
    gradient: "from-amber-500/10 to-transparent",
  },
  neutral: {
    icon: Minus,
    label: "Neutro",
    textColor: "text-sage",
    borderColor: "border-nevoa group-hover:border-sage/40",
    activeBorder: "border-sage bg-sage/5 ring-2 ring-sage/20",
    gradient: "from-sage/10 to-transparent",
  },
  numbness: {
    icon: Minus,
    label: "Dormência",
    textColor: "text-mata",
    borderColor: "border-nevoa group-hover:border-nevoa/40",
    activeBorder: "border-nevoa bg-primary/5 ring-2 ring-stone-400/20",
    gradient: "from-stone-400/10 to-transparent",
  },
};

interface SensationButtonProps {
  type: SensationType;
  selectedSensation: SensationType | null;
  onSelect: (type: SensationType) => void;
}

const SensationButton: React.FC<SensationButtonProps> = ({
  type,
  selectedSensation,
  onSelect,
}) => {
  const config = sensationConfig[type];
  const Icon = config.icon;
  const isSelected = selectedSensation === type;

  return (
    <button
      type="button"
      aria-pressed={isSelected}
      onClick={() => onSelect(type)}
      className={`
        resource-action group relative flex flex-col items-center justify-center p-3
        rounded-2xl border bg-white 
        transition-all duration-300 ease-out
        ${isSelected ? config.activeBorder : `${config.borderColor} hover:shadow-lg hover:-translate-y-1 active:scale-95`}
        overflow-hidden
      `}
    >
      {/* Background Gradient on Hover or Active */}
      <div
        className={`absolute inset-0 bg-gradient-to-br ${config.gradient} opacity-0 ${isSelected ? "opacity-100" : "group-hover:opacity-100"} transition-opacity duration-300`}
      />

      {/* Icon with scale effect */}
      <Icon
        aria-hidden="true"
        className={`w-6 h-6 mb-2 stroke-[1.5px] ${config.textColor} relative z-10 transition-transform duration-300 ${isSelected ? "scale-110" : "group-hover:scale-110"}`}
      />

      {/* Label */}
      <span
        className={`text-xs font-bold uppercase tracking-widest relative z-10 ${isSelected ? "text-mata" : "text-mata group-hover:text-mata"}`}
      >
        {config.label}
      </span>
    </button>
  );
};

const Scanner: React.FC<ScannerProps> = ({ onComplete }) => {
  const [data, setData] = useState<BodyData>({});
  const [selectedPart, setSelectedPart] = useState<BodyPartId | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);

  // Temporary state for the modal interaction
  const [tempSensation, setTempSensation] = useState<SensationType | null>(
    null,
  );
  const [tempIntensity, setTempIntensity] = useState<number>(3);
  const sheetRef = useFocusTrap<HTMLDivElement>(selectedPart !== null);

  const closeSheet = () => setSelectedPart(null);

  useEffect(() => {
    return () => {
      stopScanIntro();
    };
  }, []);

  const togglePlayback = () => {
    if (isPlaying) {
      pauseScanIntro();
      setIsPlaying(false);
    } else {
      playScanIntro(
        () => setIsPlaying(false),
        () => setIsPlaying(true),
      );
    }
  };

  const handleSavePart = () => {
    if (!selectedPart || !tempSensation) return;

    setData((prev) => ({
      ...prev,
      [selectedPart]: {
        id: selectedPart,
        label: selectedPart,
        sensation: tempSensation,
        intensity: tempIntensity,
      } as BodyLog,
    }));
    closeSheet();
  };

  return (
    <div className="flex flex-col h-full relative">
      {/* Top Bar / Audio Controls */}
      <div className="absolute top-0 left-0 right-0 p-6 flex justify-between items-start z-10 pointer-events-none">
        <div className="pointer-events-auto bg-paper/60  p-3 rounded-full border border-nevoa ">
          <button
            type="button"
            onClick={togglePlayback}
            aria-label={
              isPlaying ? "Pausar áudio guiado" : "Reproduzir áudio guiado"
            }
            aria-pressed={isPlaying}
            className="text-mata hover:text-clay transition-colors flex items-center justify-center"
          >
            {isPlaying ? (
              <Pause className="w-6 h-6 stroke-1" aria-hidden="true" />
            ) : (
              <Play className="w-6 h-6 stroke-1" aria-hidden="true" />
            )}
          </button>
        </div>

        <span className="sr-only" role="status" aria-live="polite">
          {isPlaying ? "Áudio guiado em reprodução" : "Áudio guiado pausado"}
        </span>

        <button
          type="button"
          onClick={() => onComplete(data)}
          className="resource-action pointer-events-auto bg-primary font-serif text-sm tracking-wide text-paper hover:bg-primary"
        >
          <Check className="w-4 h-4" aria-hidden="true" /> Concluir
        </button>
      </div>

      {/* Main Area */}
      <div className="flex-1 flex flex-col md:flex-row items-center justify-center relative">
        <div className="w-full max-w-md h-[60vh] md:h-[70vh] relative z-0 mt-12 md:mt-0">
          <BodyMap
            data={data}
            selectedPart={selectedPart}
            onSelectPart={(partId) => {
              if (partId) {
                const existing = data[partId];
                if (existing) {
                  setTempSensation(existing.sensation);
                  setTempIntensity(existing.intensity);
                } else {
                  setTempSensation(null);
                  setTempIntensity(3);
                }
              }
              setSelectedPart(partId);
            }}
          />
        </div>
      </div>

      {/* Sensation Selector Modal / Sheet */}
      {selectedPart && (
        <div className="absolute inset-0 z-20 bg-paper/80  flex items-end md:items-center justify-center p-4 animate-fade-in">
          <div
            ref={sheetRef}
            role="dialog"
            aria-modal="true"
            aria-labelledby="soma-scan-sheet-title"
            tabIndex={-1}
            onKeyDown={(event) => {
              if (event.key !== "Escape") return;
              event.preventDefault();
              event.stopPropagation();
              closeSheet();
            }}
            className="relative flex max-h-[calc(100%-1rem)] w-full max-w-sm flex-col space-y-5 overflow-hidden rounded-[2rem] border border-nevoa/50 bg-[#FDFAF4] p-5  sm:p-7"
          >
            {/* Background blur orb */}
            <div className="absolute -top-20 -left-20 w-40 h-40 bg-paper/50 rounded-full blur-3xl pointer-events-none"></div>

            {/* Header */}
            <div className="flex justify-between items-center mb-1 relative z-10 flex-shrink-0">
              <h3
                id="soma-scan-sheet-title"
                className="text-3xl font-serif italic text-mata"
              >
                <span className="capitalize">
                  {bodyPartTranslations[selectedPart] || selectedPart}
                </span>
              </h3>
              <button
                type="button"
                onClick={closeSheet}
                aria-label="Fechar registro de sensação"
                className="text-mata hover:text-mata transition-colors bg-paper/50 p-2 rounded-full hover:bg-paper"
              >
                <X className="w-5 h-5 stroke-1" aria-hidden="true" />
              </button>
            </div>

            <p className="text-mata text-sm font-light relative z-10">
              O que você está sentindo aqui?
            </p>

            {/* Grid Scroll Area if needed on small screens */}
            <div className="overflow-y-auto no-scrollbar py-1 relative z-10">
              <div className="grid grid-cols-2 gap-3">
                <SensationButton
                  type="tension"
                  selectedSensation={tempSensation}
                  onSelect={setTempSensation}
                />
                <SensationButton
                  type="heat"
                  selectedSensation={tempSensation}
                  onSelect={setTempSensation}
                />
                <SensationButton
                  type="weight"
                  selectedSensation={tempSensation}
                  onSelect={setTempSensation}
                />
                <SensationButton
                  type="tingling"
                  selectedSensation={tempSensation}
                  onSelect={setTempSensation}
                />
                <div className="col-span-2">
                  <SensationButton
                    type="neutral"
                    selectedSensation={tempSensation}
                    onSelect={setTempSensation}
                  />
                </div>
              </div>
            </div>

            {/* Intensity Slider - Only appears when a sensation is selected */}
            <div
              className={`space-y-4 transition-all duration-500 ease-in-out overflow-hidden relative z-10 ${tempSensation ? "opacity-100 max-h-40" : "opacity-0 max-h-0"}`}
            >
              <div className="pt-2 border-t border-nevoa/60">
                <div className="flex justify-between items-center mb-3">
                  <label
                    htmlFor="soma-scan-intensity"
                    className="text-xs font-bold uppercase tracking-widest text-mata"
                  >
                    Intensidade
                  </label>
                  <span className="text-xs font-medium text-mata bg-paper px-2 py-1 rounded-md">
                    {tempIntensity === 1
                      ? "Leve"
                      : tempIntensity === 5
                        ? "Intensa"
                        : tempIntensity}{" "}
                    / 5
                  </span>
                </div>
                <input
                  id="soma-scan-intensity"
                  type="range"
                  min="1"
                  max="5"
                  step="1"
                  value={tempIntensity}
                  aria-valuetext={`${tempIntensity === 1 ? "Leve" : tempIntensity === 5 ? "Intensa" : tempIntensity}, ${tempIntensity} de 5`}
                  onChange={(e) => setTempIntensity(parseInt(e.target.value))}
                  className="w-full h-2 bg-paper rounded-lg appearance-none cursor-pointer accent-stone-600 hover:accent-clay transition-all"
                />
                <div className="flex justify-between mt-2 text-[10px] text-mata font-medium uppercase tracking-wider">
                  <span>Sutil</span>
                  <span>Forte</span>
                </div>
              </div>
            </div>

            {/* Confirm Button */}
            <div className="relative z-10 pt-2">
              <button
                type="button"
                onClick={handleSavePart}
                disabled={!tempSensation}
                className={`resource-action
                  w-full rounded-xl font-medium tracking-wide transition-all duration-300
                  ${
                    tempSensation
                      ? "bg-primary text-paper  hover: hover:bg-primary translate-y-0"
                      : "bg-paper text-mata cursor-not-allowed "
                  }
                `}
              >
                {tempSensation ? (
                  <Save className="w-4 h-4" aria-hidden="true" />
                ) : null}
                {tempSensation
                  ? "Confirmar Registro"
                  : "Selecione uma sensação"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Floating Guidance */}
      {!selectedPart && (
        <div className="absolute bottom-8 left-0 right-0 text-center pointer-events-none">
          <p className="text-mata text-sm font-serif italic bg-paper/70 inline-block px-6 py-3 rounded-full  border border-nevoa  transition-all duration-500">
            {isPlaying
              ? "Ouça o guia. Toque no corpo para registrar sensações."
              : "Pausado. Toque no play para continuar."}
          </p>
        </div>
      )}
    </div>
  );
};

export default Scanner;
