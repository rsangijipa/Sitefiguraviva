import React, { useState, useEffect, useRef } from "react";
import { PaperCard } from "./PaperCard";
import { TECHNIQUES, SESSION_DURATION_SECONDS } from "./constants";
import { BreathingAnimation } from "./BreathingAnimation";
import {
  Play,
  ArrowLeft,
  Wind,
  Leaf,
  Info,
  CheckCircle2,
  Pause,
  Square,
  X,
  Circle,
  Disc,
  Timer,
} from "lucide-react";
import { clsx } from "clsx";
import { motion, AnimatePresence, useReducedMotion } from "framer-motion";

export default function BreathingApp() {
  // STATES: 'menu' -> 'instructions' -> 'active' -> 'completed'
  // Added 'instructions' step for pagination feel
  const [appState, setAppState] = useState("menu");
  const [selectedTechniqueId, setSelectedTechniqueId] = useState("4-6");
  const [secondsRemaining, setSecondsRemaining] = useState(
    SESSION_DURATION_SECONDS,
  );
  const [sessionActive, setSessionActive] = useState(false);
  const timerRef = useRef(null);
  const reducedMotion = useReducedMotion();

  const activeTechnique = TECHNIQUES[selectedTechniqueId];

  const completeSession = () => {
    setSessionActive(false);
    if (timerRef.current) clearInterval(timerRef.current);
    setAppState("completed");
  };

  const resetSession = () => {
    setAppState("menu");
    setSecondsRemaining(SESSION_DURATION_SECONDS);
  };

  const stopSession = () => {
    setSessionActive(false);
    if (timerRef.current) clearInterval(timerRef.current);
    setAppState("menu");
    setSecondsRemaining(SESSION_DURATION_SECONDS);
  };

  const startSession = () => {
    setAppState("active");
    setSessionActive(true);
  };

  const goToInstructions = () => {
    setAppState("instructions");
  };

  // Timer Logic
  useEffect(() => {
    if (!sessionActive) return undefined;
    timerRef.current = window.setInterval(() => {
      setSecondsRemaining((previous) => {
        if (previous <= 1) {
          window.clearInterval(timerRef.current);
          setSessionActive(false);
          setAppState("completed");
          return 0;
        }
        return previous - 1;
      });
    }, 1000);
    return () => window.clearInterval(timerRef.current);
  }, [sessionActive]);

  const formatTime = (seconds) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m}:${s.toString().padStart(2, "0")}`;
  };

  // --- SUB-COMPONENTS ---

  const StepIndicator = ({ step }) => {
    // Steps: 1=Menu, 2=Info, 3=Active, 4=Done
    const steps = [1, 2, 3, 4];
    return (
      <div
        className="flex items-center gap-2 mb-8"
        role="progressbar"
        aria-label="Progresso da prática"
        aria-valuemin={1}
        aria-valuemax={4}
        aria-valuenow={step}
        aria-valuetext={`Etapa ${step} de 4`}
      >
        {steps.map((s) => (
          <div
            key={s}
            className={`h-1.5 rounded-full transition-all duration-500 ${s <= step ? "w-6 bg-primary" : "w-2 bg-paper"}`}
          />
        ))}
      </div>
    );
  };

  // Fixed Timer Ring + 5s Spinner
  const TimerRing = ({ total, current }) => {
    const radius = 90;
    const circumference = 2 * Math.PI * radius;
    const progress = current / total;
    const strokeDashoffset = circumference - progress * circumference;

    return (
      <div
        className="relative w-48 h-48 flex items-center justify-center"
        role="timer"
        aria-live="off"
        aria-label={`${formatTime(current)} restantes`}
      >
        {/* 5-Second Loop Spinner Ring (Outer) */}
        <svg className="absolute inset-0 w-full h-full" viewBox="0 0 200 200">
          <defs>
            <linearGradient
              id="spinnerGradient"
              x1="0%"
              y1="0%"
              x2="100%"
              y2="0%"
            >
              <stop offset="0%" stopColor="#FED701" stopOpacity="0" />
              <stop offset="100%" stopColor="#FED701" stopOpacity="0.8" />
            </linearGradient>
          </defs>
          <motion.circle
            cx="100"
            cy="100"
            r={98} // Slightly larger
            fill="none"
            stroke="url(#spinnerGradient)"
            strokeWidth="2"
            strokeLinecap="round"
            strokeDasharray="100 700" // Partial arc
            animate={{ rotate: 360 }}
            transition={{ duration: 5, repeat: Infinity, ease: "linear" }}
          />
        </svg>

        {/* Progress Ring */}
        <svg
          className="absolute inset-0 w-full h-full rotate-[-90deg]"
          viewBox="0 0 200 200"
        >
          <circle
            cx="100"
            cy="100"
            r={radius}
            className="stroke-paper"
            strokeWidth="4"
            fill="none"
          />
          <motion.circle
            initial={{ strokeDashoffset: circumference }}
            animate={{ strokeDashoffset }}
            transition={{ duration: 1, ease: "linear" }}
            cx="100"
            cy="100"
            r={radius}
            className="stroke-primary/50"
            strokeWidth="4"
            fill="none"
            strokeDasharray={circumference}
            strokeLinecap="round"
          />
        </svg>

        <div className="flex flex-col items-center z-10">
          <span className="text-4xl font-sans font-light text-primary tracking-tight">
            {formatTime(current)}
          </span>
          <span className="text-xs font-bold uppercase tracking-widest text-text/80 mt-2">
            Restante
          </span>
        </div>
      </div>
    );
  };

  // --- VIEWS ---

  const renderMenu = () => (
    <motion.div
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: 20 }}
      className="max-w-5xl w-full mx-auto px-5 py-6 sm:px-8 flex flex-col items-center"
    >
      <StepIndicator step={1} />

      <header className="mb-7 text-center max-w-2xl relative">
        <h1 className="text-3xl md:text-4xl font-serif text-primary mb-3 tracking-tight">
          Escolha sua Prática
        </h1>
        <p className="text-lg font-sans text-mata">
          Selecione a técnica que melhor atende ao seu momento agora.
        </p>
      </header>

      <div className="grid md:grid-cols-2 gap-4 w-full mb-7">
        {Object.entries(TECHNIQUES).map(([id, tech]) => (
          <PaperCard
            key={id}
            onClick={() => setSelectedTechniqueId(id)}
            active={selectedTechniqueId === id}
            className={clsx(
              "cursor-pointer group h-full flex flex-col transition-all duration-300 relative overflow-hidden",
              selectedTechniqueId === id
                ? "ring-2 ring-primary border-transparent  bg-paper scale-[1.02]"
                : "hover:bg-paper/80 border-transparent",
            )}
          >
            <div className="flex justify-between items-start mb-6 relative z-10">
              <div
                className={clsx(
                  "p-3 rounded-xl transition-colors",
                  selectedTechniqueId === id
                    ? "bg-primary text-paper"
                    : "bg-paper text-mata",
                )}
              >
                {id === "4-6" ? <Timer size={24} /> : <Wind size={24} />}
              </div>
              {selectedTechniqueId === id && (
                <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }}>
                  <CheckCircle2 className="text-primary" size={24} />
                </motion.div>
              )}
            </div>

            <h3 className="text-2xl font-serif font-bold text-primary mb-2 relative z-10">
              {tech.title}
            </h3>
            <p className="font-sans text-mata mb-6 relative z-10">
              {tech.subtitle}
            </p>
          </PaperCard>
        ))}
      </div>

      <button
        onClick={goToInstructions}
        className="group relative inline-flex items-center justify-center px-10 py-5 font-serif text-xl font-bold text-paper transition-all duration-300 bg-primary rounded-full  hover: hover:-translate-y-1 w-full md:w-auto"
      >
        <span>Continuar</span>
        <ArrowLeft className="rotate-180 ml-2 group-hover:translate-x-1 transition-transform" />
      </button>
    </motion.div>
  );

  const renderInstructions = () => (
    <motion.div
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -20 }}
      className="max-w-2xl w-full mx-auto px-5 py-6 sm:px-8 flex flex-col items-center text-center"
    >
      <StepIndicator step={2} />

      <h2 className="text-3xl font-serif text-primary mb-8">
        Antes de começar...
      </h2>

      <div className="bg-paper/60 p-8 rounded-3xl border border-nevoa mb-8 w-full text-left space-y-4">
        <div className="flex items-start gap-4">
          <div className="bg-primary/10 p-2 rounded-full text-primary mt-1">
            <Leaf size={20} />
          </div>
          <p className="text-mata">
            Encontre uma posição confortável, sentado ou deitado.
          </p>
        </div>
        <div className="flex items-start gap-4">
          <div className="bg-primary/10 p-2 rounded-full text-primary mt-1">
            <Wind size={20} />
          </div>
          <p className="text-mata">
            Relaxe os ombros e destrave o maxilar.
          </p>
        </div>
        <div className="flex items-start gap-4">
          <div className="bg-primary/10 p-2 rounded-full text-primary mt-1">
            <Info size={20} />
          </div>
          <p className="text-mata">
            Siga o ritmo da animação. Se sentir tontura, pare imediatamente.
          </p>
        </div>
      </div>

      <div className="flex gap-4">
        <button
          onClick={() => setAppState("menu")}
          className="px-6 py-3 text-mata font-bold hover:bg-paper rounded-full transition-colors"
        >
          Voltar
        </button>
        <button
          onClick={startSession}
          className="px-10 py-3 bg-primary text-paper font-bold rounded-full  hover:bg-primary/90 transition-colors flex items-center gap-2"
        >
          <Play size={18} fill="currentColor" /> Iniciar Agora
        </button>
      </div>
    </motion.div>
  );

  const renderActiveSession = () => {
    const progressPercent =
      ((SESSION_DURATION_SECONDS - secondsRemaining) /
        SESSION_DURATION_SECONDS) *
      100;

    return (
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="w-full max-w-2xl mx-auto px-4 flex min-h-0 flex-col items-center justify-center"
      >
        <StepIndicator step={3} />

        <div className="mb-4 self-end">
          <button
            onClick={stopSession}
            className="flex items-center gap-2 p-3 md:px-5 md:py-2.5 rounded-full bg-paper border border-nevoa text-mata hover:text-red-500 hover:border-red-200 font-bold  transition-all"
          >
            <Square size={16} aria-hidden="true" />
            <span>Encerrar prática</span>
          </button>
        </div>

        <div className="relative mb-4 w-full flex justify-center">
          <BreathingAnimation
            technique={activeTechnique}
            isActive={sessionActive}
            onPhaseChange={() => {}}
            reducedMotion={reducedMotion}
          />
        </div>

        <div className="mb-4">
          <TimerRing
            total={SESSION_DURATION_SECONDS}
            current={secondsRemaining}
          />
        </div>

        {/* Controls */}
        <div className="flex items-center gap-6">
          <button
            type="button"
            onClick={
              sessionActive
                ? () => setSessionActive(false)
                : () => setSessionActive(true)
            }
            className="w-16 h-16 rounded-full bg-primary text-paper flex items-center justify-center  hover:scale-105 active:scale-95 transition-all"
            aria-label={sessionActive ? "Pausar prática" : "Continuar prática"}
            aria-pressed={!sessionActive}
          >
            {sessionActive ? (
              <Pause fill="currentColor" size={24} />
            ) : (
              <Play fill="currentColor" className="ml-1" size={24} />
            )}
          </button>
        </div>
      </motion.div>
    );
  };

  const renderCompleted = () => (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      className="max-w-md w-full mx-auto text-center px-6"
    >
      <StepIndicator step={4} />

      <PaperCard
        className="py-16 flex flex-col items-center bg-paper/90"
      >
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ type: "spring", stiffness: 200, damping: 15 }}
          className="w-24 h-24 bg-primary/10 rounded-full flex items-center justify-center text-primary mb-8"
        >
          <Leaf size={48} />
        </motion.div>

        <h2 className="text-4xl font-serif text-primary mb-4">
          Sessão Concluída
        </h2>
        <p className="font-sans text-lg text-mata mb-10 leading-relaxed max-w-xs mx-auto">
          Você completou seus 2 minutos. Leve essa calma com você.
        </p>

        <div className="flex flex-col gap-4 w-full">
          <button
            onClick={resetSession}
            className="bg-primary text-paper py-4 px-10 rounded-full font-sans font-bold  hover: hover:-translate-y-1 transition-all"
          >
            Voltar ao Início
          </button>
        </div>
      </PaperCard>
    </motion.div>
  );

  return (
    <div className="relative z-0 flex h-full min-h-0 w-full flex-col bg-paper">
      {/* Background Elements */}
      <div className="absolute inset-0 pointer-events-none opacity-[0.03] bg-[radial-gradient(circle_at_20%_20%,rgb(38 43 34 / .35)_1px,transparent_1px)] [background-size:18px_18px]" />
      <div className="absolute top-0 left-0 h-full w-full pointer-events-none bg-gradient-to-br from-white/40 via-blue-50/5 to-accent/5" />

      <main className="relative z-10 flex flex-1 min-h-0 flex-col justify-center py-5">
        <AnimatePresence mode="wait">
          {appState === "menu" && (
            <motion.div key="menu" className="w-full">
              {renderMenu()}
            </motion.div>
          )}
          {appState === "instructions" && (
            <motion.div key="instructions" className="w-full">
              {renderInstructions()}
            </motion.div>
          )}
          {appState === "active" && (
            <motion.div key="active" className="w-full">
              {renderActiveSession()}
            </motion.div>
          )}
          {appState === "completed" && (
            <motion.div key="completed" className="w-full">
              {renderCompleted()}
            </motion.div>
          )}
        </AnimatePresence>
      </main>
    </div>
  );
}
