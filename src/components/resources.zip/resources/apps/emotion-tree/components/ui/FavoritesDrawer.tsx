"use client";

import { AnimatePresence, motion } from "motion/react";
import { Heart, X } from "lucide-react";

import { themeLabel } from "@/components/resources/apps/emotion-tree/data/labels";
import type { Quote } from "@/components/resources/apps/emotion-tree/types/quote";

type FavoritesDrawerProps = {
  open: boolean;
  quotes: Quote[];
  onClose: () => void;
  onSelect: (quote: Quote) => void;
};

export function FavoritesDrawer({ open, quotes, onClose, onSelect }: FavoritesDrawerProps) {
  return (
    <AnimatePresence>
      {open && (
        <motion.aside
          initial={{ opacity: 0, y: 14, filter: "blur(6px)" }}
          animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
          exit={{ opacity: 0, y: 10, filter: "blur(6px)" }}
          transition={{ duration: 0.35, ease: "easeOut" }}
          className="hud-card pointer-events-auto absolute inset-x-4 bottom-4 z-40 flex max-h-[calc(100%-5rem)] flex-col rounded-[24px] p-4 -[0_24px_60px_rgb(38 43 34 / 0.45)] lg:left-auto lg:right-6 lg:w-[min(420px,calc(100%-3rem))]"
          aria-label="Frases favoritas"
        >
          <div className="mx-auto mb-3 h-1 w-12 rounded-full bg-paper/[0.18] lg:hidden" />

          <div className="mb-4 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Heart className="h-4 w-4 text-[#D8CFBE]" />
              <div>
                <p className="text-[11px] tracking-[0.18em] uppercase text-[#F1E9DB]">Favoritas</p>
                <p className="text-[11px] text-[#D8CFBE]">Salvas neste dispositivo</p>
              </div>
            </div>

            <button
              type="button"
              onClick={onClose}
              className="hud-pill flex h-8 w-8 items-center justify-center text-[#F1E9DB] transition"
              aria-label="Fechar favoritas"
            >
              <X className="h-4 w-4" />
            </button>
          </div>

          <div className="min-h-0 space-y-2 overflow-y-auto pr-1">
            {quotes.length === 0 ? (
              <p className="rounded-2xl border border-dashed border-nevoa/[0.12] bg-paper/[0.04] px-4 py-5 text-sm text-[#F1E9DB]">
                Suas frases guardadas aparecerão aqui.
              </p>
            ) : (
              quotes.map((quote) => (
                <button
                  key={quote.id}
                  type="button"
                  onClick={() => onSelect(quote)}
                  className="hud-list-item w-full px-4 py-3 text-left transition"
                >
                  <p className="text-[10px] tracking-[0.18em] uppercase text-[#D8CFBE]">{themeLabel(quote.theme)}</p>
                  <p className="mt-1 text-sm leading-relaxed text-[#FDFAF4]">{quote.text}</p>
                </button>
              ))
            )}
          </div>
        </motion.aside>
      )}
    </AnimatePresence>
  );
}
